function onLoaded() {
    window.location.href = "https://thenounproject.com/plugin/adobe/#/search";
}
